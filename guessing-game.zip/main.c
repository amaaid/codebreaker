#include <stdio.h>
#include <stdlib.h>
int main()
{
    int secretnumber= 5;
    int guess;
    int guesscount=0;
    int guesslimit=3;
    int outofguesses=0;
    
    while(guess != secretnumber && outofguesses==0){
        if (guesscount < guesslimit) {
        printf("Enter a number: ");
        scanf("%d",&guess);
        guesscount++;
    } else {
        outofguesses=1;
    }
    
    }
    if(outofguesses == 1){
      printf("out of gueses");
    }else{
        printf("You win!");
    }
    return 0;
}
